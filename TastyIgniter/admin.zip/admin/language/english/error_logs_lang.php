<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['text_title'] 		            = 'Error Logs';
$lang['text_heading'] 		            = 'Error Logs';

/* End of file error_logs_lang.php */
/* Location: ./admin/language/english/error_logs_lang.php */
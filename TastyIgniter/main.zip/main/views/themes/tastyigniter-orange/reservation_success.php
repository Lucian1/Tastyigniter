<?php echo get_header(); ?>
<div id="page-content">
	<div class="container top-spacing">
		<div class="row">
			<div class="content-wrap col-xs-9 center-block text-center">
                <p><?php echo $text_success; ?></p>

                <p><?php echo $text_signature; ?></p>
			</div>
		</div>
	</div>
</div>
<?php echo get_footer(); ?>
<?php if ( ! defined('BASEPATH')) exit('No direct access allowed');

$lang['text_heading'] 			        = 'My Order';
$lang['button_go_back'] 				= 'Add more items';

/* End of file cart_lang.php */
/* Location: ./main/language/english/main/cart_lang.php */